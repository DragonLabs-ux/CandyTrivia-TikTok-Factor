#!/usr/bin/env python3
"""Read-only Step 1 audit for the Candy Trivia TikTok Factory.

This script intentionally does not publish, schedule, cancel, delete, move,
render, install dependencies, pull Git changes, or print secret values.

It creates two local reports under out/safety-audit:
  - step1-report.json
  - step1-report.md

Run from the repository root, or pass --project PATH.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


SCRIPT_VERSION = "1.0.0"
EXPECTED_REPO_NAME = "CandyTrivia-TikTok-Factor"
DEFAULT_BRANCH = "feature/three-post-autopilot"
SECRET_NAME_RE = re.compile(
    r"(?:secret|token|password|passwd|authorization|api[_-]?key|access[_-]?key|private[_-]?key)",
    re.IGNORECASE,
)
SECRET_LINE_RE = re.compile(
    r"(?i)(secret|token|password|passwd|authorization|api[_-]?key|access[_-]?key|private[_-]?key)"
    r"\s*[:=]\s*([^\s,;]+)"
)
LONG_CREDENTIAL_RE = re.compile(r"\b[A-Za-z0-9_+/=-]{28,}\b")
QUESTION_KEYS = ("question", "questionText", "question_text", "prompt")
ANSWER_KEYS = ("answer", "correctAnswer", "correct_answer", "solution")
CAPTION_KEYS = ("caption", "description", "postText", "post_text")
SCHEDULE_KEYS = (
    "scheduledAt",
    "scheduled_at",
    "scheduledFor",
    "scheduled_for",
    "publishAt",
    "publish_at",
)
SCRIPTURE_RE = re.compile(r"\b(?:[1-3]\s*)?[A-Za-z]+(?:\s+[A-Za-z]+)?\s+\d{1,3}:\d{1,3}\b")


@dataclass(frozen=True)
class QuestionRecord:
    file: str
    path: str
    fingerprint: str


@dataclass(frozen=True)
class CaptionRecord:
    file: str
    path: str
    fingerprint: str
    kind: str
    scripture_reference: str | None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def normalize_text(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value or ""))
    return " ".join(text.casefold().split())


def short_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_relative(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.name


def redact_text(text: str) -> str:
    text = SECRET_LINE_RE.sub(lambda match: f"{match.group(1)}=<REDACTED>", text)
    return LONG_CREDENTIAL_RE.sub("<REDACTED_LONG_VALUE>", text)


def command_path(*candidates: str) -> str | None:
    for candidate in candidates:
        found = shutil.which(candidate)
        if found:
            return found
    return None


def run_read_only(command: list[str], cwd: Path, timeout: int = 180) -> dict[str, Any]:
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            shell=False,
        )
        output = redact_text((completed.stdout or "") + (completed.stderr or ""))
        return {
            "command": command,
            "exit_code": completed.returncode,
            "output": output.strip(),
        }
    except (OSError, subprocess.SubprocessError) as exc:
        return {"command": command, "exit_code": None, "output": f"ERROR: {exc}"}


def env_key_names(root: Path) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for path in sorted(root.glob(".env*")):
        if not path.is_file():
            continue
        keys: list[str] = []
        try:
            for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key = line.split("=", 1)[0].strip()
                if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
                    keys.append(key)
        except OSError:
            continue
        result[safe_relative(path, root)] = sorted(set(keys))
    return result


def walk_json(value: Any, path: str = "$") -> Iterable[tuple[str, Any]]:
    yield path, value
    if isinstance(value, dict):
        for key, child in value.items():
            yield from walk_json(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from walk_json(child, f"{path}[{index}]")


def value_for_keys(mapping: dict[str, Any], candidates: Iterable[str]) -> Any | None:
    lookup = {str(key).casefold(): value for key, value in mapping.items()}
    for candidate in candidates:
        if candidate.casefold() in lookup:
            return lookup[candidate.casefold()]
    return None


def schema_paths(value: Any, prefix: str = "$", depth: int = 0) -> set[str]:
    if depth > 8:
        return {f"{prefix}:depth-limit"}
    if isinstance(value, dict):
        paths = {f"{prefix}:object"}
        for key, child in value.items():
            paths.update(schema_paths(child, f"{prefix}.{key}", depth + 1))
        return paths
    if isinstance(value, list):
        paths = {f"{prefix}:array"}
        for child in value[:3]:
            paths.update(schema_paths(child, f"{prefix}[]", depth + 1))
        return paths
    if value is None:
        kind = "null"
    elif isinstance(value, bool):
        kind = "boolean"
    elif isinstance(value, (int, float)):
        kind = "number"
    else:
        kind = "string"
    return {f"{prefix}:{kind}"}


def classify_caption(caption: str) -> str:
    normalized = normalize_text(caption)
    if re.search(r"(?:^|\s)(?:answer|correct answer)\b", normalized) or "✅ answer" in caption.casefold():
        return "answer"
    if "fill in" in normalized or "comment your answer" in normalized or "comment your answers" in normalized:
        return "question"
    return "standard"


def extract_records(
    data: Any, relative_file: str
) -> tuple[list[QuestionRecord], list[CaptionRecord], list[str], list[str]]:
    questions: list[QuestionRecord] = []
    captions: list[CaptionRecord] = []
    schedules: list[str] = []
    channel_fields: list[str] = []

    for json_path, value in walk_json(data):
        if not isinstance(value, dict):
            continue

        question = value_for_keys(value, QUESTION_KEYS)
        answer = value_for_keys(value, ANSWER_KEYS)
        options = value_for_keys(value, ("options", "answers", "choices"))
        if question is not None and (answer is not None or options is not None):
            answer_material = answer if answer is not None else options
            normalized = f"{normalize_text(question)}\n{normalize_text(answer_material)}"
            questions.append(QuestionRecord(relative_file, json_path, short_hash(normalized)))

        for key, child in value.items():
            key_folded = str(key).casefold()
            if key in CAPTION_KEYS or key_folded in {name.casefold() for name in CAPTION_KEYS}:
                if isinstance(child, str) and child.strip():
                    reference_match = SCRIPTURE_RE.search(child)
                    captions.append(
                        CaptionRecord(
                            relative_file,
                            f"{json_path}.{key}",
                            short_hash(normalize_text(child)),
                            classify_caption(child),
                            reference_match.group(0) if reference_match else None,
                        )
                    )
            if key in SCHEDULE_KEYS or key_folded in {name.casefold() for name in SCHEDULE_KEYS}:
                if isinstance(child, (str, int, float)):
                    schedules.append(str(child))
            if ("channel" in key_folded or "profile" in key_folded) and "id" in key_folded:
                channel_fields.append(f"{json_path}.{key}")

    return questions, captions, schedules, sorted(set(channel_fields))


def discover_state_files(root: Path) -> list[dict[str, Any]]:
    patterns = ("*manifest*.json", "*state*.json", "*history*.jsonl", "*analytics*.jsonl")
    found: dict[Path, None] = {}
    for base in (root, root / "out", root / "data", root / "private", root / "examples"):
        if not base.exists():
            continue
        for pattern in patterns:
            for path in base.rglob(pattern):
                if path.is_file() and "node_modules" not in path.parts:
                    found[path] = None

    records: list[dict[str, Any]] = []
    for path in sorted(found):
        record: dict[str, Any] = {
            "file": safe_relative(path, root),
            "size_bytes": path.stat().st_size,
        }
        try:
            if path.suffix.casefold() == ".jsonl":
                lines = [line for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()]
                record["record_count"] = len(lines)
                if lines:
                    parsed = json.loads(lines[0])
                    record["schema"] = sorted(schema_paths(parsed))[:200]
            else:
                parsed = json.loads(path.read_text(encoding="utf-8", errors="replace"))
                record["schema"] = sorted(schema_paths(parsed))[:200]
                if isinstance(parsed, list):
                    record["record_count"] = len(parsed)
                elif isinstance(parsed, dict):
                    record["top_level_key_count"] = len(parsed)
        except (OSError, json.JSONDecodeError) as exc:
            record["parse_error"] = str(exc)
        records.append(record)
    return records


def inspect_videos(root: Path) -> dict[str, Any]:
    out_dir = root / "out"
    if not out_dir.exists():
        return {"count": 0, "files": [], "exact_duplicate_groups": []}

    paths = sorted(out_dir.glob("*.mp4"), key=lambda item: item.stat().st_mtime, reverse=True)
    hash_groups: dict[str, list[str]] = defaultdict(list)
    records: list[dict[str, Any]] = []
    ffprobe = command_path("ffprobe.exe", "ffprobe")

    for path in paths[:100]:
        digest = file_sha256(path)
        relative = safe_relative(path, root)
        hash_groups[digest].append(relative)
        record: dict[str, Any] = {
            "file": relative,
            "size_bytes": path.stat().st_size,
            "sha256_prefix": digest[:16],
        }
        if ffprobe:
            probe = run_read_only(
                [
                    ffprobe,
                    "-v",
                    "error",
                    "-show_entries",
                    "format=duration:stream=codec_type,width,height",
                    "-of",
                    "json",
                    str(path),
                ],
                root,
                timeout=30,
            )
            if probe["exit_code"] == 0:
                try:
                    metadata = json.loads(probe["output"])
                    duration = metadata.get("format", {}).get("duration")
                    streams = metadata.get("streams", [])
                    video_stream = next((stream for stream in streams if stream.get("codec_type") == "video"), {})
                    record.update(
                        {
                            "duration_seconds": round(float(duration), 3) if duration else None,
                            "width": video_stream.get("width"),
                            "height": video_stream.get("height"),
                            "has_audio": any(stream.get("codec_type") == "audio" for stream in streams),
                        }
                    )
                except (ValueError, json.JSONDecodeError):
                    record["probe_error"] = "Could not parse ffprobe output"
        records.append(record)

    duplicate_groups = [files for files in hash_groups.values() if len(files) > 1]
    return {
        "count": len(paths),
        "inspected_count": len(records),
        "ffprobe_available": bool(ffprobe),
        "files": records,
        "exact_duplicate_groups": duplicate_groups,
    }


def summarize_json(root: Path) -> dict[str, Any]:
    candidates: list[Path] = []
    for base in (root / "examples" / "auto", root / "examples"):
        if base.exists():
            candidates.extend(path for path in base.rglob("*.json") if path.is_file())
    candidates = sorted(set(candidates))

    question_records: list[QuestionRecord] = []
    caption_records: list[CaptionRecord] = []
    deck_groups: dict[str, list[str]] = defaultdict(list)
    schedule_by_file: dict[str, list[str]] = {}
    channel_paths_by_file: dict[str, list[str]] = {}
    schemas: list[dict[str, Any]] = []
    parse_errors: list[dict[str, str]] = []

    for path in candidates:
        relative = safe_relative(path, root)
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError) as exc:
            parse_errors.append({"file": relative, "error": str(exc)})
            continue

        questions, captions, schedules, channel_fields = extract_records(data, relative)
        question_records.extend(questions)
        caption_records.extend(captions)
        if questions:
            deck_hash = short_hash("|".join(record.fingerprint for record in questions))
            deck_groups[deck_hash].append(relative)
        if schedules:
            schedule_by_file[relative] = schedules
        if channel_fields:
            channel_paths_by_file[relative] = channel_fields
        if len(schemas) < 5:
            schemas.append({"file": relative, "schema": sorted(schema_paths(data))[:300]})

    question_groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    for record in question_records:
        question_groups[record.fingerprint].append({"file": record.file, "path": record.path})

    caption_groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    for record in caption_records:
        caption_groups[record.fingerprint].append({"file": record.file, "path": record.path})

    reference_groups: dict[str, dict[str, list[str]]] = defaultdict(lambda: {"question": [], "answer": []})
    for record in caption_records:
        if record.scripture_reference and record.kind in ("question", "answer"):
            reference_groups[record.scripture_reference][record.kind].append(record.file)

    split_pairs = []
    for reference, groups in sorted(reference_groups.items()):
        if groups["question"] and groups["answer"]:
            split_pairs.append(
                {
                    "reference": reference,
                    "question_files": sorted(set(groups["question"])),
                    "answer_files": sorted(set(groups["answer"])),
                }
            )

    return {
        "file_count": len(candidates),
        "parsed_count": len(candidates) - len(parse_errors),
        "parse_errors": parse_errors,
        "question_slot_count": len(question_records),
        "unique_question_fingerprints": len(question_groups),
        "repeated_question_groups": [
            {"fingerprint": fingerprint, "occurrences": occurrences}
            for fingerprint, occurrences in sorted(question_groups.items())
            if len({item["file"] for item in occurrences}) > 1
        ],
        "duplicate_deck_groups": [
            {"fingerprint": fingerprint, "files": sorted(files)}
            for fingerprint, files in sorted(deck_groups.items())
            if len(files) > 1
        ],
        "repeated_caption_groups": [
            {"fingerprint": fingerprint, "occurrences": occurrences}
            for fingerprint, occurrences in sorted(caption_groups.items())
            if len({item["file"] for item in occurrences}) > 1
        ],
        "question_answer_split_pairs": split_pairs,
        "caption_kind_counts": dict(Counter(record.kind for record in caption_records)),
        "schedule_by_file": schedule_by_file,
        "channel_id_field_paths": channel_paths_by_file,
        "sample_schemas": schemas,
    }


def git_report(root: Path) -> dict[str, Any]:
    git = command_path("git.exe", "git")
    if not git:
        return {"available": False}
    commands = {
        "root": [git, "rev-parse", "--show-toplevel"],
        "branch": [git, "branch", "--show-current"],
        "status": [git, "status", "--short", "--branch"],
        "recent_commits": [git, "log", "-5", "--oneline"],
    }
    results = {name: run_read_only(command, root, timeout=30) for name, command in commands.items()}
    branch = results["branch"].get("output", "").strip()
    return {
        "available": True,
        "expected_branch": DEFAULT_BRANCH,
        "branch_matches_expected": branch == DEFAULT_BRANCH,
        "commands": results,
    }


def package_report(root: Path) -> dict[str, Any]:
    package_path = root / "package.json"
    if not package_path.exists():
        return {"found": False}
    try:
        data = json.loads(package_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {"found": True, "error": str(exc)}
    scripts = data.get("scripts", {}) if isinstance(data, dict) else {}
    return {
        "found": True,
        "name": data.get("name"),
        "version": data.get("version"),
        "scripts": scripts,
        "has_typecheck": "typecheck" in scripts,
        "has_channels": "channels" in scripts,
        "publish_script_names": sorted(name for name in scripts if "publish" in name.casefold()),
    }


def online_report(root: Path, package: dict[str, Any], enabled: bool) -> dict[str, Any]:
    if not enabled:
        return {"enabled": False, "note": "Run with --online to execute the read-only channels command."}
    npm = command_path("npm.cmd", "npm")
    if not npm:
        return {"enabled": True, "error": "npm was not found"}
    scripts = package.get("scripts", {})
    if "channels" not in scripts:
        return {"enabled": True, "error": "package.json has no channels script"}
    result = run_read_only([npm, "run", "channels"], root, timeout=120)
    result["contains_expected_buffer_label"] = "dragonlabs0" in result.get("output", "").casefold()
    result["contains_public_handle"] = "triviacandyfun" in result.get("output", "").casefold()
    return {"enabled": True, "channels": result}


def typecheck_report(root: Path, package: dict[str, Any], skip: bool) -> dict[str, Any]:
    if skip:
        return {"skipped": True}
    npm = command_path("npm.cmd", "npm")
    if not npm:
        return {"skipped": False, "error": "npm was not found"}
    if not package.get("has_typecheck"):
        return {"skipped": False, "error": "package.json has no typecheck script"}
    result = run_read_only([npm, "run", "typecheck"], root, timeout=240)
    return {"skipped": False, **result}


def important_inventory(root: Path) -> list[dict[str, Any]]:
    relative_paths = (
        "scripts/full-autopilot-v27.py",
        "src/dedupe.ts",
        "src/cli.ts",
        "candy_v27_update_and_audit.py",
        "package.json",
        "package-lock.json",
    )
    inventory = []
    for relative in relative_paths:
        path = root / relative
        inventory.append(
            {
                "file": relative,
                "exists": path.exists(),
                "size_bytes": path.stat().st_size if path.is_file() else None,
            }
        )
    return inventory


def risks(report: dict[str, Any]) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    git = report.get("git", {})
    if git.get("available") and not git.get("branch_matches_expected"):
        findings.append({"severity": "HIGH", "code": "WRONG_BRANCH", "message": "The active Git branch is not the expected autopilot branch."})

    content = report.get("content", {})
    if content.get("duplicate_deck_groups"):
        findings.append({"severity": "BLOCK", "code": "DUPLICATE_DECKS", "message": "Duplicate full quiz decks exist in generated JSON."})
    if content.get("repeated_question_groups"):
        findings.append({"severity": "HIGH", "code": "REPEATED_QUESTIONS", "message": "Question fingerprints repeat across generated posts."})
    if content.get("repeated_caption_groups"):
        findings.append({"severity": "HIGH", "code": "REPEATED_CAPTIONS", "message": "Identical captions are assigned to multiple generated posts."})
    if content.get("question_answer_split_pairs"):
        findings.append({"severity": "BLOCK", "code": "SPLIT_QUESTION_ANSWER", "message": "Question and answer posts appear to be split for the same scripture reference."})

    videos = report.get("videos", {})
    if videos.get("exact_duplicate_groups"):
        findings.append({"severity": "BLOCK", "code": "DUPLICATE_MP4", "message": "Exact duplicate MP4 files exist in out/."})
    for item in videos.get("files", []):
        duration = item.get("duration_seconds")
        if duration is not None and not (8.0 <= duration <= 35.0):
            findings.append({"severity": "HIGH", "code": "VIDEO_DURATION", "message": f"{item['file']} duration is outside the 8–35 second safety range."})
        if item.get("has_audio") is False:
            findings.append({"severity": "BLOCK", "code": "NO_AUDIO", "message": f"{item['file']} has no audio stream."})

    typecheck = report.get("typecheck", {})
    if typecheck.get("exit_code") not in (None, 0):
        findings.append({"severity": "BLOCK", "code": "TYPECHECK_FAILED", "message": "TypeScript validation failed."})
    return findings


def markdown_report(report: dict[str, Any]) -> str:
    content = report["content"]
    videos = report["videos"]
    findings = report["findings"]
    lines = [
        "# Candy Trivia TikTok Factory — Step 1 Safety Audit",
        "",
        f"Generated: `{report['generated_at']}`",
        f"Audit script: `{report['audit_script_version']}`",
        f"Project: `{report['project']['path']}`",
        "",
        "## Safety guarantee",
        "",
        "This audit did not publish, schedule, cancel, delete, move, render, install, pull, or print secret values.",
        "",
        "## Summary",
        "",
        f"- Package version: `{report['package'].get('version', 'unknown')}`",
        f"- Generated JSON files: `{content.get('file_count', 0)}`",
        f"- Question slots: `{content.get('question_slot_count', 0)}`",
        f"- Duplicate deck groups: `{len(content.get('duplicate_deck_groups', []))}`",
        f"- Repeated question groups: `{len(content.get('repeated_question_groups', []))}`",
        f"- Repeated caption groups: `{len(content.get('repeated_caption_groups', []))}`",
        f"- Question/answer split pairs: `{len(content.get('question_answer_split_pairs', []))}`",
        f"- MP4 files: `{videos.get('count', 0)}`",
        f"- Exact duplicate MP4 groups: `{len(videos.get('exact_duplicate_groups', []))}`",
        "",
        "## Findings",
        "",
    ]
    if findings:
        for finding in findings:
            lines.append(f"- **{finding['severity']} — {finding['code']}**: {finding['message']}")
    else:
        lines.append("- No local blocking findings were detected. Remote Buffer/TikTok reconciliation is still required before publishing.")

    lines.extend(["", "## Duplicate deck groups", ""])
    groups = content.get("duplicate_deck_groups", [])
    if groups:
        for group in groups:
            lines.append(f"- `{group['fingerprint']}`: {', '.join(f'`{name}`' for name in group['files'])}")
    else:
        lines.append("- None detected locally.")

    lines.extend(["", "## Question/answer split pairs", ""])
    split_pairs = content.get("question_answer_split_pairs", [])
    if split_pairs:
        for pair in split_pairs:
            lines.append(
                f"- **{pair['reference']}** — questions: {', '.join(pair['question_files'])}; answers: {', '.join(pair['answer_files'])}"
            )
    else:
        lines.append("- None detected locally.")

    lines.extend(
        [
            "",
            "## Next step",
            "",
            "Send this Markdown report back to ChatGPT. Do not run any publish, autopilot, or scheduling command yet.",
            "The next script will reconcile the actual Buffer queue and install the v2.8 safety gate using the schemas recorded in step1-report.json.",
            "",
        ]
    )
    return "\n".join(lines)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Read-only Candy Trivia TikTok Factory safety audit")
    parser.add_argument("--project", type=Path, default=Path.cwd(), help="Repository root (default: current directory)")
    parser.add_argument("--online", action="store_true", help="Also run the existing read-only npm channels command")
    parser.add_argument("--skip-typecheck", action="store_true", help="Skip npm run typecheck")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = args.project.expanduser().resolve()
    package_path = root / "package.json"
    if not root.exists() or not package_path.exists():
        print(f"ERROR: {root} is not the Candy Trivia project root (package.json not found).", file=sys.stderr)
        return 2

    package = package_report(root)
    report: dict[str, Any] = {
        "generated_at": utc_now(),
        "audit_script_version": SCRIPT_VERSION,
        "safety_mode": "READ_ONLY",
        "project": {"path": str(root), "folder_name": root.name, "expected_folder_name": EXPECTED_REPO_NAME},
        "git": git_report(root),
        "package": package,
        "important_files": important_inventory(root),
        "environment_key_names_only": env_key_names(root),
        "content": summarize_json(root),
        "publish_state_files": discover_state_files(root),
        "videos": inspect_videos(root),
        "typecheck": typecheck_report(root, package, args.skip_typecheck),
        "online_channel_check": online_report(root, package, args.online),
    }
    report["findings"] = risks(report)

    report_dir = root / "out" / "safety-audit"
    report_dir.mkdir(parents=True, exist_ok=True)
    json_path = report_dir / "step1-report.json"
    markdown_path = report_dir / "step1-report.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    markdown_path.write_text(markdown_report(report), encoding="utf-8")

    blocking = sum(1 for finding in report["findings"] if finding["severity"] == "BLOCK")
    high = sum(1 for finding in report["findings"] if finding["severity"] == "HIGH")
    print("=" * 72)
    print("CANDY TRIVIA TIKTOK FACTORY — STEP 1 READ-ONLY AUDIT")
    print("=" * 72)
    print(f"Project: {root}")
    print(f"Package version: {package.get('version', 'unknown')}")
    print(f"JSON files: {report['content']['file_count']}")
    print(f"Question slots: {report['content']['question_slot_count']}")
    print(f"MP4 files: {report['videos']['count']}")
    print(f"Blocking findings: {blocking}")
    print(f"High findings: {high}")
    print()
    print("NO POSTS WERE PUBLISHED, SCHEDULED, CANCELLED, OR DELETED.")
    print(f"Report: {markdown_path}")
    print(f"Details: {json_path}")
    print()
    print("Send step1-report.md back to ChatGPT. Do not publish yet.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
