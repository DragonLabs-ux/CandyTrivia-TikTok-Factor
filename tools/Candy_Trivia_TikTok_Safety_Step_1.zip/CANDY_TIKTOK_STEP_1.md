# Candy Trivia TikTok Safety Reset — Step 1

This first step collects the exact local project structure needed to build the safe v2.8 upgrade.

It does **not** publish, schedule, cancel, delete, move, render, install packages, pull Git changes, or expose credential values.

## Put the script here

Save `candy_tiktok_step1_audit.py` in:

```text
C:\Users\perry\AI\ChatGPT\CandyTrivia-TikTok-Factor
```

## Run this one command in PowerShell

```powershell
cd "C:\Users\perry\AI\ChatGPT\CandyTrivia-TikTok-Factor"

python .\candy_tiktok_step1_audit.py --online
```

The script runs the existing TypeScript check and the existing read-only Buffer channel listing. It never invokes the publish or autopilot commands.

## Send back one file

When it finishes, upload or paste:

```text
out\safety-audit\step1-report.md
```

Keep the more detailed `step1-report.json` on your computer unless ChatGPT specifically asks for it.

Do not run `full-autopilot-v27.py`, `npm run publish`, or another scheduling command before Step 2.

Step 2 will use the report to reconcile the actual Buffer queue and install the v2.8 semantic duplicate, channel, cover, caption, audio, and canary-publishing safeguards.
