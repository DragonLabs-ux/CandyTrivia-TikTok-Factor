#!/usr/bin/env python3
"""Read-only Step 2 reconciliation for Candy Trivia TikTok Factory.

This script:
  * audits only the 42 campaign definitions in examples/auto/post-*.json;
  * checks exact repeated questions and captions;
  * reads the local Buffer manifest/state;
  * performs read-only Buffer queries for the configured channel and known posts;
  * writes a proposed plan under out/safety-audit.

It cannot publish, schedule, edit, cancel, delete, render, move files, pull Git,
install dependencies, or run the autopilot.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import unicodedata
import urllib.error
import urllib.request
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCRIPT_VERSION = "1.0.0"
EXPECTED_REPO = "CandyTrivia-TikTok-Factor"
BUFFER_ENDPOINT = "https://api.buffer.com"
AUTO_GLOB = "post-*.json"


@dataclass(frozen=True)
class CampaignPost:
    file: str
    post_id: str
    scheduled_at: str
    caption: str
    questions: tuple[tuple[str, str, str], ...]


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def normalize(value: Any) -> str:
    return " ".join(unicodedata.normalize("NFKC", str(value or "")).casefold().split())


def fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def masked_id(value: str | None) -> str:
    if not value:
        return "unknown"
    return f"…{value[-8:]}" if len(value) > 8 else value


def load_env_file(path: Path) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            os.environ.setdefault(key, value)


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.is_file():
        return rows
    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        if not raw.strip():
            continue
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                rows.append(parsed)
        except json.JSONDecodeError:
            rows.append({"_parse_error": f"line {line_no}"})
    return rows


def extract_questions(data: dict[str, Any]) -> tuple[tuple[str, str, str], ...]:
    questions: list[tuple[str, str, str]] = []
    source = data.get("questions")
    if isinstance(source, list):
        for index, item in enumerate(source, 1):
            if isinstance(item, dict):
                question = item.get("question") or item.get("questionText") or item.get("prompt")
                answer = item.get("answer") or item.get("correctAnswer") or item.get("solution")
                if question is not None and answer is not None:
                    questions.append((f"questions[{index}]", str(question), str(answer)))
    for key in ("q1", "q2", "q3"):
        item = data.get(key)
        if isinstance(item, dict):
            question = item.get("question") or item.get("questionText") or item.get("prompt")
            answer = item.get("answer") or item.get("correctAnswer") or item.get("solution")
            if question is not None and answer is not None:
                questions.append((key, str(question), str(answer)))
    return tuple(questions)


def load_campaign(root: Path) -> tuple[list[CampaignPost], list[str]]:
    posts: list[CampaignPost] = []
    errors: list[str] = []
    auto_dir = root / "examples" / "auto"
    for path in sorted(auto_dir.glob(AUTO_GLOB)):
        data = read_json(path)
        relative = path.relative_to(root).as_posix()
        if not isinstance(data, dict):
            errors.append(f"{relative}: invalid JSON object")
            continue
        questions = extract_questions(data)
        if not questions:
            errors.append(f"{relative}: no question/answer pairs found")
            continue
        posts.append(
            CampaignPost(
                file=relative,
                post_id=str(data.get("id") or path.stem.removeprefix("post-")),
                scheduled_at=str(data.get("scheduledAt") or ""),
                caption=str(data.get("caption") or ""),
                questions=questions,
            )
        )
    return posts, errors


def order_key(post: CampaignPost) -> tuple[str, str]:
    return (post.scheduled_at or "9999", post.file)


def local_findings(posts: list[CampaignPost]) -> dict[str, Any]:
    question_groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    caption_groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    deck_groups: dict[str, list[str]] = defaultdict(list)

    by_file = {post.file: post for post in posts}
    for post in posts:
        question_fps: list[str] = []
        for slot, question, answer in post.questions:
            item_fp = fingerprint(f"{normalize(question)}\n{normalize(answer)}")
            question_fps.append(item_fp)
            question_groups[item_fp].append({"file": post.file, "post_id": post.post_id, "slot": slot})
        deck_groups[fingerprint("|".join(question_fps))].append(post.file)
        caption_groups[fingerprint(normalize(post.caption))].append(
            {"file": post.file, "post_id": post.post_id}
        )

    repeated_questions = []
    for item_fp, occurrences in sorted(question_groups.items()):
        files = sorted({item["file"] for item in occurrences})
        if len(files) < 2:
            continue
        ordered = sorted(files, key=lambda name: order_key(by_file[name]))
        repeated_questions.append(
            {"fingerprint": item_fp, "keep": ordered[0], "hold": ordered[1:], "occurrences": occurrences}
        )

    repeated_captions = []
    for item_fp, occurrences in sorted(caption_groups.items()):
        files = sorted({item["file"] for item in occurrences})
        if len(files) < 2:
            continue
        ordered = sorted(files, key=lambda name: order_key(by_file[name]))
        repeated_captions.append(
            {"fingerprint": item_fp, "keep": ordered[0], "rewrite": ordered[1:], "occurrences": occurrences}
        )

    return {
        "campaign_file_count": len(posts),
        "question_slot_count": sum(len(post.questions) for post in posts),
        "duplicate_deck_groups": [
            {"fingerprint": item_fp, "files": sorted(files)}
            for item_fp, files in sorted(deck_groups.items())
            if len(files) > 1
        ],
        "repeated_question_groups": repeated_questions,
        "repeated_caption_groups": repeated_captions,
    }


def graphql(api_key: str, query: str, variables: dict[str, Any]) -> dict[str, Any]:
    body = json.dumps({"query": query, "variables": variables}).encode("utf-8")
    request = urllib.request.Request(
        BUFFER_ENDPOINT,
        data=body,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if payload.get("errors"):
        raise RuntimeError("; ".join(str(item.get("message", "GraphQL error")) for item in payload["errors"]))
    return payload.get("data") or {}


def inspect_buffer(api_key: str, channel_id: str, manifest: list[dict[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {"queried": True, "channel": None, "posts": [], "errors": []}
    organizations_query = """
      query Organizations { account { organizations { id name } } }
    """
    channels_query = """
      query Channels($organizationId: OrganizationId!) {
        channels(input: { organizationId: $organizationId }) { id name service }
      }
    """
    post_query = """
      query Post($id: PostId!) {
        post(input: { id: $id }) {
          id status dueAt sentAt createdAt allowedActions text
        }
      }
    """
    try:
        org_data = graphql(api_key, organizations_query, {})
        organizations = ((org_data.get("account") or {}).get("organizations") or [])
        channels: list[dict[str, Any]] = []
        for organization in organizations:
            data = graphql(api_key, channels_query, {"organizationId": organization.get("id")})
            for channel in data.get("channels") or []:
                record = dict(channel)
                record["organization"] = organization.get("name")
                channels.append(record)
        selected = next((item for item in channels if item.get("id") == channel_id), None)
        result["channel"] = selected or {"id": channel_id, "matched": False}
    except (urllib.error.URLError, TimeoutError, RuntimeError, ValueError) as exc:
        result["errors"].append(f"Channel lookup failed: {exc}")

    known_ids: dict[str, set[str]] = defaultdict(set)
    for row in manifest:
        buffer_id = row.get("bufferPostId")
        if buffer_id:
            known_ids[str(buffer_id)].add(str(row.get("day") or "unknown"))
    for buffer_id in sorted(known_ids):
        try:
            data = graphql(api_key, post_query, {"id": buffer_id})
            post = data.get("post")
            if not isinstance(post, dict):
                raise RuntimeError("post was not returned")
            result["posts"].append({**post, "local_days": sorted(known_ids[buffer_id])})
        except (urllib.error.URLError, TimeoutError, RuntimeError, ValueError) as exc:
            result["posts"].append(
                {"id": buffer_id, "local_days": sorted(known_ids[buffer_id]), "lookup_error": str(exc)}
            )
    return result


def proposed_actions(
    local: dict[str, Any], manifest: list[dict[str, Any]], buffer_result: dict[str, Any]
) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    repeated_by_file: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for group in local["repeated_question_groups"]:
        for file in group["hold"]:
            repeated_by_file[file].append((group["fingerprint"], group["keep"]))
    for file, repeats in sorted(repeated_by_file.items()):
        actions.append(
            {
                "action": "HOLD_AND_REGENERATE_QUESTION",
                "file": file,
                "question_fingerprints": [item[0] for item in repeats],
                "reason": "repeats question(s) found in " + ", ".join(sorted({item[1] for item in repeats})),
                "applied": False,
            }
        )
    duplicate_deck_files: set[str] = set()
    for group in local["duplicate_deck_groups"]:
        for file in group["files"][1:]:
            duplicate_deck_files.add(file)
    for file in sorted(duplicate_deck_files):
        if file not in repeated_by_file:
            actions.append(
                {
                    "action": "HOLD_DUPLICATE_DECK",
                    "file": file,
                    "reason": "duplicates a complete quiz deck",
                    "applied": False,
                }
            )
    for group in local["repeated_caption_groups"]:
        for file in group["rewrite"]:
            actions.append(
                {
                    "action": "REWRITE_CAPTION_ONLY",
                    "file": file,
                    "reason": f"repeats caption {group['fingerprint']}; keep {group['keep']}",
                    "applied": False,
                }
            )

    by_day: dict[str, set[str]] = defaultdict(set)
    for row in manifest:
        if row.get("day") and row.get("bufferPostId"):
            by_day[str(row["day"])].add(str(row["bufferPostId"]))
    remote_by_id = {str(item.get("id")): item for item in buffer_result.get("posts", []) if item.get("id")}
    for day, ids in sorted(by_day.items()):
        if len(ids) < 2:
            continue
        posts = [remote_by_id.get(item_id, {"id": item_id}) for item_id in ids]
        actions.append(
            {
                "action": "REVIEW_BUFFER_DAY_DUPLICATE",
                "day": day,
                "buffer_post_ids": sorted(ids),
                "statuses": [item.get("status") or "unknown" for item in posts],
                "reason": "multiple Buffer post IDs are recorded for one campaign day",
                "applied": False,
            }
        )
    return actions


def markdown(report: dict[str, Any]) -> str:
    local = report["local_campaign"]
    buffer_data = report["buffer"]
    lines = [
        "# Candy Trivia TikTok Factory — Step 2 Reconciliation",
        "",
        f"Generated: `{report['generated_at']}`",
        f"Script: `{report['script_version']}`",
        "",
        "## Safety guarantee",
        "",
        "Read-only preview. Nothing was published, scheduled, edited, cancelled, deleted, rendered, moved, installed, pulled, or run through the autopilot.",
        "",
        "## Corrected campaign scope",
        "",
        f"- Campaign definitions checked: `{local['campaign_file_count']}` (`examples/auto/post-*.json` only)",
        f"- Question slots checked: `{local['question_slot_count']}`",
        f"- Duplicate full decks: `{len(local['duplicate_deck_groups'])}`",
        f"- Repeated campaign questions: `{len(local['repeated_question_groups'])}`",
        f"- Repeated campaign captions: `{len(local['repeated_caption_groups'])}`",
        "- The standalone `examples/day-001.json` sample is deliberately excluded.",
        "",
        "## Repeated questions",
        "",
    ]
    if local["repeated_question_groups"]:
        for group in local["repeated_question_groups"]:
            lines.append(
                f"- `{group['fingerprint']}` — keep `{group['keep']}`; hold/regenerate: "
                + ", ".join(f"`{name}`" for name in group["hold"])
            )
    else:
        lines.append("- None inside the actual 42-post campaign. The Step 1 warning came from its broader 43-file scope.")

    lines.extend(["", "## Repeated captions", ""])
    if local["repeated_caption_groups"]:
        for group in local["repeated_caption_groups"]:
            lines.append(
                f"- `{group['fingerprint']}` — keep `{group['keep']}`; rewrite caption only: "
                + ", ".join(f"`{name}`" for name in group["rewrite"])
            )
        lines.append("")
        lines.append("Repeated captions are a creative-quality issue, not proof of duplicate videos. They do not require deleting or rerendering unique MP4 files.")
    else:
        lines.append("- None inside the actual campaign.")

    lines.extend(["", "## Buffer read-only inventory", ""])
    channel = buffer_data.get("channel")
    if isinstance(channel, dict):
        lines.append(
            f"- Configured channel: `{channel.get('name', 'unmatched')}` / `{channel.get('service', 'unknown')}` / `{masked_id(channel.get('id'))}`"
        )
    for error in buffer_data.get("errors", []):
        lines.append(f"- Lookup warning: {error}")
    posts = buffer_data.get("posts", [])
    if posts:
        for post in posts:
            lines.append(
                f"- `{masked_id(post.get('id'))}` — local day(s) {', '.join(post.get('local_days', []))}; "
                f"status `{post.get('status', 'unknown')}`; due `{post.get('dueAt') or 'n/a'}`; sent `{post.get('sentAt') or 'n/a'}`"
            )
    else:
        lines.append("- No known Buffer post IDs were present in `out/manifest.jsonl`, or Buffer access was unavailable.")

    lines.extend(["", "## Proposed Step 3 actions — not applied", ""])
    actions = report["proposed_actions"]
    if actions:
        for item in actions:
            target = item.get("file") or item.get("day") or "unknown"
            lines.append(f"- **{item['action']}** — `{target}`: {item['reason']}")
    else:
        lines.append("- No holds, caption rewrites, or duplicate-day reviews are currently proposed.")
    lines.extend(
        [
            "",
            "## Next step",
            "",
            "Send this Markdown report back to ChatGPT. Do not publish, schedule, cancel, delete, or run the autopilot.",
            "Step 3 will be prepared only after this report is reviewed and you approve its exact proposed changes.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only Candy Trivia Step 2 reconciliation")
    parser.add_argument("--project", type=Path, default=Path.cwd(), help="Repository root")
    parser.add_argument("--offline", action="store_true", help="Skip read-only Buffer queries")
    args = parser.parse_args()
    root = args.project.resolve()
    if root.name != EXPECTED_REPO or not (root / "package.json").is_file():
        print(f"ERROR: run from the {EXPECTED_REPO} repository root, or pass --project PATH.", file=sys.stderr)
        return 2

    posts, load_errors = load_campaign(root)
    local = local_findings(posts)
    manifest = read_jsonl(root / "out" / "manifest.jsonl")
    state_path = root / ".private" / "candy-publisher-state.json"
    state = read_json(state_path, {}) if state_path.is_file() else {}
    step1 = read_json(root / "out" / "safety-audit" / "step1-report.json", {})

    buffer_result: dict[str, Any] = {"queried": False, "channel": None, "posts": [], "errors": []}
    if args.offline:
        buffer_result["errors"].append("Buffer query skipped with --offline")
    else:
        load_env_file(root / ".env")
        api_key = os.environ.get("BUFFER_API_KEY", "")
        channel_id = os.environ.get("BUFFER_TIKTOK_CHANNEL_ID", "")
        if not api_key or not channel_id:
            buffer_result["errors"].append("BUFFER_API_KEY or BUFFER_TIKTOK_CHANNEL_ID is unavailable; local audit completed")
        else:
            buffer_result = inspect_buffer(api_key, channel_id, manifest)

    report = {
        "generated_at": now_utc(),
        "script_version": SCRIPT_VERSION,
        "safety_mode": "read-only",
        "project": str(root),
        "step1_summary": {
            "available": isinstance(step1, dict) and bool(step1),
            "reported_json_files": ((step1.get("content") or {}).get("file_count") if isinstance(step1, dict) else None),
        },
        "load_errors": load_errors,
        "local_campaign": local,
        "manifest": {"path": "out/manifest.jsonl", "record_count": len(manifest)},
        "publisher_state": {"path": ".private/candy-publisher-state.json", "available": bool(state)},
        "buffer": buffer_result,
    }
    report["proposed_actions"] = proposed_actions(local, manifest, buffer_result)

    out_dir = root / "out" / "safety-audit"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "step2-report.json"
    md_path = out_dir / "step2-report.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    md_path.write_text(markdown(report), encoding="utf-8")

    print("STEP 2 READ-ONLY RECONCILIATION COMPLETE")
    print(f"Campaign files: {local['campaign_file_count']}")
    print(f"Repeated campaign questions: {len(local['repeated_question_groups'])}")
    print(f"Repeated campaign captions: {len(local['repeated_caption_groups'])}")
    print(f"Known Buffer posts checked: {len(buffer_result.get('posts', []))}")
    print(f"Proposed actions (not applied): {len(report['proposed_actions'])}")
    print(f"Report: {md_path}")
    print("Nothing was published, scheduled, cancelled, deleted, rendered, or run through the autopilot.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
