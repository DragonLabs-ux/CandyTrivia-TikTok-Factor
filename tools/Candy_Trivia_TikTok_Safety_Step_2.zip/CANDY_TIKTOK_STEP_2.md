# Candy Trivia TikTok Safety — Step 2

Step 2 corrects the Step 1 audit scope and performs a read-only Buffer reconciliation.

It does **not** publish, schedule, edit, cancel, delete, render, move files, install dependencies, pull Git changes, or run the autopilot.

## Why this step is necessary

Step 1 counted 43 JSON files, but the production campaign has 42 posts. The extra file is the standalone sample `examples/day-001.json`. Step 2 audits only `examples/auto/post-*.json`, so sample content cannot create a false repeated-question warning.

Repeated captions are handled separately. Identical captions can weaken performance, but they do not prove the MP4 files are duplicates. Step 2 proposes caption-only rewrites and leaves all files and Buffer posts unchanged.

## Run exactly one command

From PowerShell in the repository root:

```powershell
python .\candy_tiktok_step2_reconcile.py
```

If `python` is not recognized, use:

```powershell
py .\candy_tiktok_step2_reconcile.py
```

The script reads `.env` for Buffer access, but never prints the key or channel ID. Its Buffer operations are read-only queries for the configured channel and post IDs already recorded in `out\manifest.jsonl`.

## Send back one file

Upload:

```text
out\safety-audit\step2-report.md
```

Do not send `.env` or the private publisher-state file. Do not run the autopilot, publish, schedule, cancel, or delete anything.

Step 3 will be prepared only after the report and its proposed actions are reviewed.
